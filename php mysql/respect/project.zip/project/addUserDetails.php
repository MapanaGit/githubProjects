<?php

$servername = "localhost";
$database = "communityservice";
$username = "root";
$password = "";
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
}
 
echo "Connected successfully";

/*if(isset($_POST['submit']))
{    
     $username = $_POST['username'];
     $password = $_POST['password'];
     */
    echo "BIS Project";
     $sql = "INSERT INTO admin (username,password) VALUES ('Lawrence', 'Mashau')";
     
    
     if (mysqli_query($conn, $sql)) {
        echo "Login details have been recorded";
  } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
  mysqli_close($conn);
//}
?>