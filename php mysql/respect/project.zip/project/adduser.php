<?php
session_start();

$servername = "localhost";
$username = "root";
$password = "";
$database = "communityservice";
        $conn = mysqli_connect("$servername", "$username", "$password", "$database");
         
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }

        echo "Connected successfully"; 
         
    if(isset($_POST['submit'])){
        
        $fullname = $_REQUEST['fullname'];
        $surname =  $_REQUEST['surname'];
        $userid = $_REQUEST['userid'];
        $address = $_REQUEST['address'];
          $contacts = $_REQUEST['contacts'];
      $typeofdonation = $_REQUEST['typeofdonation'];
        $comment = $_REQUEST['comment'];
       
        $sql = "INSERT INTO requestdonation  VALUES (null,'$fullname','$surname','$userid','$address','$contacts','$typeofdonation','$comment')";
         
        if(mysqli_query($conn, $sql)){
            echo "<script>alert('Request has been sent successfully')</script>";
           
        } else{
            echo "<script>alert('Request has not been sent')</script>";
                
        }
    }
        // Close connection
        mysqli_close($conn);
    session_destroy();
        ?>