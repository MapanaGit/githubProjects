<?php
session_start();
class User{
  

 public function addUsers(){
        
           
    $servername = "localhost";
    $database = "communityservice";
    $username = "root";
    $password = "";
    $conn = mysqli_connect($servername, $username, $password, $database);
    // Check connection
    if (!$conn) {
          die("Connection failed: " . mysqli_connect_error());
    }
     
    echo "Connected successfully";
    
    if(isset($_POST['submit']))
    {    
         $fullname = $_POST['fullname'];
         $surname = $_POST['surname'];
         $idnumber = $_POST['idnumber'];
         $address = $_POST['address'];
         $contact = $_POST['contact'];
         $gender = $_POST['gender'];
         $email = $_POST['email'];
         
        
         $sql = "INSERT INTO user (fullname,surname,idnumber,address,contact,gender,email) VALUES ('$fullname', '$surname','$idnumber','$address','$contact','$gender','$email')";
         
        //$sql = "INSERT INTO users (name,email,mobile)
         //VALUES ('$sonia','$sonia@gmail.com','$0798567421')";
         if (mysqli_query($conn, $sql)) {
            echo "New record created successfully";
      } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($conn);
      }
      mysqli_close($conn);
    }
}


    public function addUserCredentials(){
       
           
        $servername = "localhost";
        $database = "communityservice";
        $username = "root";
        $password = "";
        $conn = mysqli_connect($servername, $username, $password, $database);
        // Check connection
        if (!$conn) {
              die("Connection failed: " . mysqli_connect_error());
        }
         
        
        
        if(isset($_POST['submit']))
        {    
             $uName = $_POST['surname'];
             $uPass = $_POST['pass1']; 
             
             
            
             $sql = "INSERT INTO admin (username,userPassword) VALUES ('$uName', '$uPass')";
                        
             if (mysqli_query($conn, $sql)) {
                echo "New record created successfully";
          } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
          }
          mysqli_close($conn);
        }
    }
}

$lg=new User();
$lg->addUsers();
$lg->addUserCredentials();
 
?>
