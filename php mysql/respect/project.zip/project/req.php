<?php

$servername = "localhost";
$database = "communityservice";
$username = "root";
$password = "";
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
}
 
echo "Connected successfully";

if(isset($_POST['submit']))
{    
     $fullname = $_POST['fullname'];
     $surname = $_POST['surname'];
     $address = $_POST['address'];
     $contact = $_POST['contact'];
     $typeofdonation = $_POST['typeofdonation'];
     $comment = $_POST['comment'];
     $idnumber = $_POST['idnumber'];
         
     $sql = "INSERT INTO requestdonation (fullname,surname,address,contact,typeofdonation,comment,idnumber) VALUES ('$fullname', '$surname','$address','$contact','$typeofdonation','$comment','$idnumber')";
    
     if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
  } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
  mysqli_close($conn);
}
?>
