<?php
$servername = "localhost";
$database = "test";
$username = "root";
$password = "";
// Create connection
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
}
 
echo "Connected successfully";
 
$sql = "INSERT INTO person1 (firstname, lastname,id,address,contacts,email,gender,role) VALUES ('vhuhwavho12', 'Phungo','0112280931083','thohoyandou 0950','0827313750','Testing@tesing.com','female','admin')";
if (mysqli_query($conn, $sql)) {
      echo "New record created successfully";

      <?php
// define variables and set to empty values
$firstnameErr = $lastnameErr = $idErr = $addressErr = $contactsErr = $emailErr = $genderErr = $roleErr = "";
$firstname = $lastname = $id = $address = $contacts = $email = $gender = $role= "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
  if (empty($_POST["firstname"])) {
    $firstnameErr = "Firstname is required";
  } else {
    $firstname = test_input($_POST["firstname"]);
  }
  if (empty($_POST["lastname"])) {
      $lastnameErr = "Lastname is required";
    } else {
      $lastname = test_input($_POST["lastname"]);
  }
  if (empty($_POST["id"])) {
      $idErr = "Id is required";
    } else {
      $id = test_input($_POST["id"]);
    }
    if (empty($_POST["address"])) {
      $addressErr = "Address is required";
    } else {
      $address = test_input($_POST["address"]);
    }
    if (empty($_POST["contacts"])) {
      $contactsErr = "Contacts is required";
    } else {
      $contacts = test_input($_POST["contacts"]);
    }
  if (empty($_POST["email"])) {
    $emailErr = "Email is required";
  } else {
    $email = test_input($_POST["email"]);
  }

  if (empty($_POST["role"])) {
      $roleErr = "Role is required";
    } else {
      $role = test_input($_POST["role"]);

  if (empty($_POST["gender"])) {
    $genderErr = "Gender is required";
  } else {
    $gender = test_input($_POST["gender"]);
  }
}
?>

} else {
      echo "Error: " . $sql . "<br>" . mysqli_error($conn);
}
mysqli_close($conn);
?>