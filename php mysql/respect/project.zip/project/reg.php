<?php

$servername = "localhost";
$database = "communityservice";
$username = "root";
$password = "";
$conn = mysqli_connect($servername, $username, $password, $database);
// Check connection
if (!$conn) {
      die("Connection failed: " . mysqli_connect_error());
}
 
echo "Connected successfully";

if(isset($_POST['submit']))
{    
     $fullname = $_POST['fullname'];
     $surname = $_POST['surname'];
     $idnumber = $_POST['idnumber'];
     $address = $_POST['address'];
     $contact = $_POST['contact'];
     $gender = $_POST['gender'];
     $email = $_POST['email'];
     
    
     $sql = "INSERT INTO user (fullname,surname,idnumber,address,contact,gender,email) VALUES ('$fullname', '$surname','$idnumber','$address','$contact','$gender','$email')";
     
    //$sql = "INSERT INTO users (name,email,mobile)
     //VALUES ('$sonia','$sonia@gmail.com','$0798567421')";
     if (mysqli_query($conn, $sql)) {
        echo "New record created successfully";
  } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
  }
  mysqli_close($conn);
}
?>
<script type="text/javascript">

function validate(){
	if(document.register.fullname.value==""){
		alert('username is required');
		document.register.fullname.focus();
		return false;
	}
	if(document.register.surname.value==""){
		alert('surname is required');
		document.register.surname.focus();
		return false;
	}
	if(document.register.idnumber.value==""){
		alert('idnumber is required');
		document.register.idnumber.focus();
		return false;
	}
      if(document.register.address.value==""){
		alert('addressis required');
		document.register.address.focus();
		return false;
	}
      if(document.register.contact.value==""){
		alert('contact is required');
		document.register.contact.focus();
		return false;
	}
      if(document.register.email.value==""){
		alert('email is required');
		document.register.email.focus();
		return false;
	}
      if(document.register.gender.value==""){
		alert('gender is required');
		document.register.gender.focus();
		return false;
	}
      if(document.register.pass1.value==""){
		alert('pass1 is required');
		document.register.pass1.focus();
		return false;
	}
	return(true);
}

</script>