<?php
session_start();
class Authentication{
 public function authenticate_User(){
        $servername='localhost';
        $username='root';
        $password='';
        $dbName='communityservice';
     
        


//if(isset($_POST['submit']))
 //{
   
        $lUserName=$_POST['userName1'];
        $pass=$_POST['pass1'];



        $conn= new mysqli($servername,$username, $password,$dbName);
    

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}


       
        $displayUserDataQry="SELECT * FROM admin WHERE username='$lUserName' and userPassword='$pass'";
       
        $excuteUserData=$conn->query($displayUserDataQry);
 
        if ($excuteUserData->num_rows>0){
               include 'request.php';  
             
                exit();
         } else{
            $lp=new Authentication();
            $lp->openNewPage();
            
         }
        }

        function openNewPage(){
            include 'WrongCredential.php'; 
        }
}
 
//}
// this goes to a controller.

$lg=new Authentication();
$lg->authenticate_User();
 
?>
