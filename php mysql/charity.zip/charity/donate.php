<?php

session_start();
 
        $conn = mysqli_connect("localhost", "rayzedda_root", "Covid192021*", "rayzedda_db");
        // Check connection
        if($conn === false){
            die("ERROR: Could not connect. "
                . mysqli_connect_error());
        }
     if(isset($_POST['submit'])){
        $name =  $_REQUEST['name'];
        $email = $_REQUEST['email'];
        $contact = $_REQUEST['contact'];
        $amount = $_REQUEST['amount'];
		$reference = $_REQUEST['reference'];
               
        // Performing insert query execution
        
        $sql = "INSERT INTO donation(id,name,email,contact,amount,reference) VALUES (null,'$name','$email','$contact','$amount','$reference')";
         
        if(mysqli_query($conn, $sql)){
            echo "<script>alert('Thank you for donating the amount of R '+ $amount)</script>";
           
        } else{
            echo "<script>alert('No donation was made. Please try again')</script>";
                
        }
     }
         
        // Close connection
        mysqli_close($conn);
    session_destroy();
 ?>
<!DOCTYPE html>
<!--[if lt IE 7]>      <html class="no-js lt-ie9 lt-ie8 lt-ie7"> <![endif]-->
<!--[if IE 7]>         <html class="no-js lt-ie9 lt-ie8"> <![endif]-->
<!--[if IE 8]>         <html class="no-js lt-ie9"> <![endif]-->
<!--[if gt IE 8]><!--> <html class="no-js"> <!--<![endif]-->
	<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<title>Donate | Razye Group</title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" />
	<meta name="keywords" />
	<meta name="author" />

  <!-- 
	//////////////////////////////////////////////////////

	FREE HTML5 TEMPLATE 
	DESIGNED & DEVELOPED by FREEHTML5.CO
		
	Website: 		http://freehtml5.co/
	Email: 			info@freehtml5.co
	Twitter: 		http://twitter.com/fh5co
	Facebook: 		https://www.facebook.com/fh5co

	//////////////////////////////////////////////////////
	 -->

  	<!-- Facebook and Twitter integration -->
	<meta property="og:title" content=""/>
	<meta property="og:image" content=""/>
	<meta property="og:url" content=""/>
	<meta property="og:site_name" content=""/>
	<meta property="og:description" content=""/>
	<meta name="twitter:title" content="" />
	<meta name="twitter:image" content="" />
	<meta name="twitter:url" content="" />
	<meta name="twitter:card" content="" />

	<!-- Place favicon.ico and apple-touch-icon.png in the root directory -->
	<link rel="shortcut icon" href="favicon.ico">

	<!-- <link href='https://fonts.googleapis.com/css?family=Open+Sans:400,700,300' rel='stylesheet' type='text/css'> -->
	
	<!-- Animate.css -->
	<link rel="stylesheet" href="css/animate.css">
	<!-- Icomoon Icon Fonts-->
	<link rel="stylesheet" href="css/icomoon.css">
	<!-- Bootstrap  -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<!-- Superfish -->
	<link rel="stylesheet" href="css/superfish.css">

	<link rel="stylesheet" href="css/style.css">


	<!-- Modernizr JS -->
	<script src="js/modernizr-2.6.2.min.js"></script>
	<!-- FOR IE9 below -->
	<!--[if lt IE 9]>
	<script src="js/respond.min.js"></script>
	<![endif]-->
<style>
select[name=amount]{
  width: 100%;
  padding: 12px 20px;
  margin: 8px 0;
  display: inline-block;
  border: 1px solid #ccc;
  box-sizing: border-box;
}
</style>
	</head>
	<body>
		<div id="fh5co-wrapper">
		<div id="fh5co-page">
		<div class="header-top">
			<div class="container">
				<div class="row">
					<div class="col-md-6 col-sm-6 text-left fh5co-link">
						<a href="#">t:(+27 82) 092 8105</a>
						<a href="mailto:projects@rayzegroup.org.za">e:projects@rayzegroup.org.za</a>
						<a href="mailto:admin@rayzegroup.org.za">e:admin@rayzegroup.org.za</a>
					</div>
					<div class="col-md-6 col-sm-6 text-right fh5co-social">
						<a href="#" class="grow"><i class="icon-facebook2"></i></a>
						<a href="#" class="grow"><i class="icon-twitter2"></i></a>
						<a href="#" class="grow"><i class="icon-instagram2"></i></a>
					</div>
				</div>
			</div>
		</div>
		<header id="fh5co-header-section" class="sticky-banner">
			<div class="container">
				<div class="nav-header">
					<a href="#" class="js-fh5co-nav-toggle fh5co-nav-toggle dark"><i></i></a>
					<h1 id="fh5co-logo"><a href="index.html">Rayze &nbsp;Group <br>NGO. EST. 2018</a></h1>
					<!-- START #fh5co-menu-wrap -->
					<nav id="fh5co-menu-wrap" role="navigation">
						<ul class="sf-menu" id="fh5co-primary-menu">
							<li>
								<a href="index.html">Home</a>
							</li>
							<li><a href="values.html">Business values</a></li>
							<li>
								<a href="#" class="fh5co-sub-ddown">Core programs</a>
								<ul class="fh5co-sub-menu">
									<li><a href="about.html">Teach a child</a></li>
									<li><a href="chilren.html">Children and youth development</a></li>
									<li><a href="community.html">Community empowerment</a></li>
									<li><a href="capacity.html">Capacity building</a></li>
									<li><a href="gender.html">Gender and victim empowerment</a></li>
									
								</ul>
							</li>
							
							<li><a href="events.html">Events</a></li>
							<li class="active"><a href="donate.php">Donate</a></li>
							<li>
								<a href="#" class="fh5co-sub-ddown">Join Us</a>
								<ul class="fh5co-sub-menu">
									<li><a href="careers.html">Careers</a></li>
									<li><a href="volunteer.html">Volunteers</a></li>
								</ul>
							</li>
							<li><a href="contact.php">Contact</a></li>
						</ul>
					</nav>
				</div>
			</div>
		</header>
		
		

		<div class="fh5co-hero">
			<div class="fh5co-overlay"></div>
			<div class="fh5co-cover text-center" data-stellar-background-ratio="0.5" style="background-image: url(images/cover_bg_2.jpg);">
				<div class="desc animate-box">
					<h2>Your donation will<strong>  make a difference </strong> </h2>
					<span></span>
					<span><a class="btn btn-primary btn-lg" href="donate.php">Donate Now</a></span>
				</div>
			</div>

		</div>
		
		<div id="fh5co-contact" class="animate-box">
			<div class="container">
				<form action="donate.php" method="post">
					<div class="row">
						<div class="col-md-6">
							<h3 class="section-title">Donation form</h3>
							<p>Please see our bank account details below</p>
							<ul class="contact-info">
								<li><i class="fa fa-money"></i>123456789</li>
								<li><i class="fa fa-money"></i>FNB Account</li>
								<li><i class="fa fa-money"></i>Savings</li>
								<li><i class="fa fa-money"></i>(+27 82) 092 8105</li>
							</ul>
						</div>
						<div class="col-md-6">
							<div class="row">
								<div class="col-md-12">
									<div class="form-group">
										<input type="text" name="name" id="name" class="form-control" placeholder="Full Name" required>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<input type="email" name="email" id="email" class="form-control" placeholder="Email Address" required>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<input type="number" name="contact" id="contact" class="form-control" placeholder="Contact Number" max-length="15" required>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<label for="cars">Amount</label>

										<select name="amount" id="amount">
											<option value="10">R10.00</option>
											<option value="20">R20.00</option>
											<option value="50">R50.00</option>
											<option value="100">R100.00</option>
											<option value="200">R200.00</option>
										</select>
									</div>
								</div>
								<div class="col-md-12">
									<div class="form-group">
										<input type="text" name="reference" id="reference" class="form-control" placeholder="Donor reference and contact details" max-length="100" required>
									</div>
								</div>
								
								<div class="col-md-12">
									<div class="form-group">
										<input type="submit" name="submit" value="Donate" class="btn btn-primary">
									</div>
								</div>
							</div>
						</div>
					</div>
				</form>
			</div>
		</div>
		<!-- END fh5co-contact -->
		
		<!-- END map -->

		
		<footer>
			<div id="footer">
				<div class="container">
					<div class="row">
						<div class="col-md-6 col-md-offset-3 text-center">
							<p class="fh5co-social-icons">
								<a href="#"><i class="icon-twitter2"></i></a>
								<a href="#"><i class="icon-facebook2"></i></a>
								<a href="#"><i class="icon-instagram"></i></a>
								<a href="#"><i class="icon-dribbble2"></i></a>
								<a href="#"><i class="icon-youtube"></i></a>
							</p>
							<p>t:(+27 82) 092 8105 | Copyright &copy; Rayze Group. 2023 | e:projects@rayzegroup.org | e:admin@rayzegroup.org.za</p>
						</div>
					</div>
				</div>
			</div>
		</footer>
	

	</div>
	<!-- END fh5co-page -->

	</div>
	<!-- END fh5co-wrapper -->

	<!-- jQuery -->


	<script src="js/jquery.min.js"></script>
	<!-- jQuery Easing -->
	<script src="js/jquery.easing.1.3.js"></script>
	<!-- Bootstrap -->
	<script src="js/bootstrap.min.js"></script>
	<!-- Waypoints -->
	<script src="js/jquery.waypoints.min.js"></script>
	<script src="js/sticky.js"></script>

	<!-- Stellar -->
	<script src="js/jquery.stellar.min.js"></script>
	<!-- Superfish -->
	<script src="js/hoverIntent.js"></script>
	<script src="js/superfish.js"></script>

	<!-- Google Map -->
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyCefOgb1ZWqYtj7raVSmN4PL2WkTrc-KyA&sensor=false"></script>
	<script src="js/google_map.js"></script>
	
	<!-- Main JS -->
	<script src="js/main.js"></script>
<!--Whatsapp widget-->
<script async src='https://d2mpatx37cqexb.cloudfront.net/delightchat-whatsapp-widget/embeds/embed.min.js'></script>
        <script>
          var wa_btnSetting = {"btnColor":"#16BE45","ctaText":"WhatsApp Us","cornerRadius":40,"marginBottom":20,"marginLeft":20,"marginRight":20,"btnPosition":"right","whatsAppNumber":"27820928105","welcomeMessage":"Rayze Group welcomes you, how can we help you?","zIndex":999999,"btnColorScheme":"light"};
          window.onload = () => {
            _waEmbed(wa_btnSetting);
          };
        </script>
      
	</body>
</html>

