package pharmacy_management_system;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class POS extends JFrame {

    // ==============================
    // DATABASE SETTINGS
    // ==============================
    private final String DB_URL =
            "jdbc:mysql://localhost:3306/pharmacy_db";
    private final String DB_USER = "root";
    private final String DB_PASSWORD = "";

    // Logged-in cashier/user ID
    // Change this when connecting your login system.
    private int userId = 2;

    // ==============================
    // GUI COMPONENTS
    // ==============================
    private JTextField txtSearch;
    private JTextField txtMedicineId;
    private JTextField txtMedicineName;
    private JTextField txtPrice;
    private JTextField txtStock;
    private JTextField txtQuantity;
    private JTextField txtAmountPaid;

    private JLabel lblTotal;
    private JLabel lblChange;

    private JTable tblCart;
    private DefaultTableModel model;

    public POS() {
        initComponents();
    }

    public POS(int userId) {
        this.userId = userId;
        initComponents();
    }

    // ==============================
    // DATABASE CONNECTION
    // ==============================
    private Connection getConnection() throws SQLException {

        try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            throw new SQLException("MySQL JDBC Driver not found.", ex);
        }

        return DriverManager.getConnection(
                DB_URL,
                DB_USER,
                DB_PASSWORD
        );
    }

    // ==============================
    // CREATE GUI
    // ==============================
    private void initComponents() {

        setTitle("Pharmacy Management System - Point of Sale");
        setSize(900, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // ------------------------------
        // Search panel
        // ------------------------------
        JPanel searchPanel = new JPanel(new FlowLayout());

        searchPanel.add(new JLabel("Search Medicine:"));

        txtSearch = new JTextField(20);
        searchPanel.add(txtSearch);

        JButton btnSearch = new JButton("Search");
        searchPanel.add(btnSearch);

        add(searchPanel, BorderLayout.NORTH);

        // ------------------------------
        // Medicine information panel
        // ------------------------------
        JPanel medicinePanel = new JPanel(new GridLayout(3, 4, 5, 5));

        medicinePanel.add(new JLabel("Medicine ID:"));
        txtMedicineId = new JTextField();
        txtMedicineId.setEditable(false);
        medicinePanel.add(txtMedicineId);

        medicinePanel.add(new JLabel("Medicine Name:"));
        txtMedicineName = new JTextField();
        txtMedicineName.setEditable(false);
        medicinePanel.add(txtMedicineName);

        medicinePanel.add(new JLabel("Price:"));
        txtPrice = new JTextField();
        txtPrice.setEditable(false);
        medicinePanel.add(txtPrice);

        medicinePanel.add(new JLabel("Stock:"));
        txtStock = new JTextField();
        txtStock.setEditable(false);
        medicinePanel.add(txtStock);

        medicinePanel.add(new JLabel("Quantity:"));
        txtQuantity = new JTextField();
        medicinePanel.add(txtQuantity);

        JButton btnAdd = new JButton("Add To Cart");
        medicinePanel.add(btnAdd);

        JButton btnClear = new JButton("Clear");
        medicinePanel.add(btnClear);

        add(medicinePanel, BorderLayout.CENTER);

        // ------------------------------
        // Cart table
        // ------------------------------
        model = new DefaultTableModel(
                new Object[]{
                    "Medicine ID",
                    "Medicine Name",
                    "Quantity",
                    "Unit Price",
                    "Total Amount"
                }, 0) {

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tblCart = new JTable(model);

        JScrollPane scrollPane = new JScrollPane(tblCart);

        add(scrollPane, BorderLayout.SOUTH);

        // ------------------------------
        // Bottom panel
        // ------------------------------
        JPanel bottomPanel = new JPanel(new FlowLayout());

        bottomPanel.add(new JLabel("Total: R"));

        lblTotal = new JLabel("0.00");
        bottomPanel.add(lblTotal);

        bottomPanel.add(new JLabel("Amount Paid: R"));

        txtAmountPaid = new JTextField(8);
        bottomPanel.add(txtAmountPaid);

        bottomPanel.add(new JLabel("Change: R"));

        lblChange = new JLabel("0.00");
        bottomPanel.add(lblChange);

        JButton btnRemove = new JButton("Remove");
        bottomPanel.add(btnRemove);

        JButton btnCompleteSale = new JButton("Complete Sale");
        bottomPanel.add(btnCompleteSale);

        // Put bottom controls in a separate frame panel
        JPanel controlPanel = new JPanel(new BorderLayout());
        controlPanel.add(bottomPanel, BorderLayout.CENTER);

        add(controlPanel, BorderLayout.PAGE_END);

        // ------------------------------
        // Button events
        // ------------------------------
        btnSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                searchMedicine();
            }
        });

        btnAdd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addToCart();
            }
        });

        btnRemove.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeFromCart();
            }
        });

        btnClear.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                clearSale();
            }
        });

        btnCompleteSale.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                completeSale();
            }
        });

        txtAmountPaid.addKeyListener(new java.awt.event.KeyAdapter() {
            @Override
            public void keyReleased(java.awt.event.KeyEvent evt) {
                calculateChange();
            }
        });
    }

    // ==============================
    // SEARCH MEDICINE
    // ==============================
    private void searchMedicine() {

        String search = txtSearch.getText().trim();

        if (search.isEmpty()) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a medicine name."
            );
            return;
        }

        String sql =
                "SELECT medicine_id, name, price, quantity_in_stock " +
                "FROM medicines " +
                "WHERE name LIKE ?";

        try {
            Connection con = getConnection();
            PreparedStatement pst = con.prepareStatement(sql);

            pst.setString(1, "%" + search + "%");

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {

                txtMedicineId.setText(
                        rs.getString("medicine_id")
                );

                txtMedicineName.setText(
                        rs.getString("name")
                );

                txtPrice.setText(
                        rs.getString("price")
                );

                txtStock.setText(
                        rs.getString("quantity_in_stock")
                );

            } else {

                JOptionPane.showMessageDialog(
                        this,
                        "Medicine not found."
                );

                txtMedicineId.setText("");
                txtMedicineName.setText("");
                txtPrice.setText("");
                txtStock.setText("");
            }

            rs.close();
            pst.close();
            con.close();

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Database error:\n" + ex.getMessage()
            );
        }
    }

    // ==============================
    // ADD TO CART
    // ==============================
    private void addToCart() {

        try {

            if (txtMedicineId.getText().trim().isEmpty()) {

                JOptionPane.showMessageDialog(
                        this,
                        "Please search for a medicine first."
                );

                return;
            }

            int medicineId =
                    Integer.parseInt(txtMedicineId.getText());

            String medicineName =
                    txtMedicineName.getText();

            double price =
                    Double.parseDouble(txtPrice.getText());

            int stock =
                    Integer.parseInt(txtStock.getText());

            int quantity =
                    Integer.parseInt(txtQuantity.getText());

            if (quantity <= 0) {

                JOptionPane.showMessageDialog(
                        this,
                        "Quantity must be greater than zero."
                );

                return;
            }

            if (quantity > stock) {

                JOptionPane.showMessageDialog(
                        this,
                        "Insufficient stock.\nAvailable stock: "
                        + stock
                );

                return;
            }

            double subtotal = price * quantity;

            // If medicine is already in cart, increase quantity.
            for (int i = 0; i < model.getRowCount(); i++) {

                int existingId =
                        Integer.parseInt(
                                model.getValueAt(i, 0).toString()
                        );

                if (existingId == medicineId) {

                    int oldQuantity =
                            Integer.parseInt(
                                    model.getValueAt(i, 2).toString()
                            );

                    int newQuantity =
                            oldQuantity + quantity;

                    if (newQuantity > stock) {

                        JOptionPane.showMessageDialog(
                                this,
                                "The total quantity in the cart "
                                + "cannot exceed available stock.\n"
                                + "Available: " + stock
                        );

                        return;
                    }

                    model.setValueAt(
                            newQuantity,
                            i,
                            2
                    );

                    model.setValueAt(
                            price * newQuantity,
                            i,
                            4
                    );

                    calculateTotal();
                    txtQuantity.setText("");

                    return;
                }
            }

            model.addRow(new Object[]{
                medicineId,
                medicineName,
                quantity,
                price,
                subtotal
            });

            calculateTotal();

            txtQuantity.setText("");

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid quantity."
            );
        }
    }

    // ==============================
    // CALCULATE TOTAL
    // ==============================
    private void calculateTotal() {

        double total = 0;

        for (int i = 0; i < model.getRowCount(); i++) {

            double subtotal =
                    Double.parseDouble(
                            model.getValueAt(i, 4).toString()
                    );

            total = total + subtotal;
        }

        lblTotal.setText(
                String.format("%.2f", total)
        );

        calculateChange();
    }

    // ==============================
    // CALCULATE CHANGE
    // ==============================
    private void calculateChange() {

        try {

            double total =
                    Double.parseDouble(lblTotal.getText());

            double paid =
                    Double.parseDouble(
                            txtAmountPaid.getText()
                    );

            double change = paid - total;

            if (change >= 0) {

                lblChange.setText(
                        String.format("%.2f", change)
                );

            } else {

                lblChange.setText("Insufficient");
            }

        } catch (NumberFormatException ex) {

            lblChange.setText("0.00");
        }
    }

    // ==============================
    // REMOVE FROM CART
    // ==============================
    private void removeFromCart() {

        int selectedRow =
                tblCart.getSelectedRow();

        if (selectedRow == -1) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please select an item to remove."
            );

            return;
        }

        model.removeRow(selectedRow);

        calculateTotal();
    }

    // ==============================
    // CLEAR SALE
    // ==============================
    private void clearSale() {

        model.setRowCount(0);

        txtSearch.setText("");
        txtMedicineId.setText("");
        txtMedicineName.setText("");
        txtPrice.setText("");
        txtStock.setText("");
        txtQuantity.setText("");
        txtAmountPaid.setText("");

        lblTotal.setText("0.00");
        lblChange.setText("0.00");
    }

    // ==============================
    // COMPLETE SALE
    // ==============================
    private void completeSale() {

        if (model.getRowCount() == 0) {

            JOptionPane.showMessageDialog(
                    this,
                    "The cart is empty."
            );

            return;
        }

        try {

            double total =
                    Double.parseDouble(
                            lblTotal.getText()
                    );

            double amountPaid =
                    Double.parseDouble(
                            txtAmountPaid.getText()
                    );

            if (amountPaid < total) {

                JOptionPane.showMessageDialog(
                        this,
                        "Insufficient payment."
                );

                return;
            }

            double change =
                    amountPaid - total;

            int answer = JOptionPane.showConfirmDialog(
                    this,
                    "Total: R "
                    + String.format("%.2f", total)
                    + "\nAmount Paid: R "
                    + String.format("%.2f", amountPaid)
                    + "\nChange: R "
                    + String.format("%.2f", change)
                    + "\n\nComplete this sale?",
                    "Confirm Sale",
                    JOptionPane.YES_NO_OPTION
            );

            if (answer != JOptionPane.YES_OPTION) {
                return;
            }

            Connection con = getConnection();

            try {

                con.setAutoCommit(false);

                // ------------------------------
                // Insert into sales
                // ------------------------------
                String saleSQL =
                        "INSERT INTO sales "
                        + "(user_id, sale_date, total_amount) "
                        + "VALUES (?, NOW(), ?)";

                PreparedStatement salePst =
                        con.prepareStatement(
                                saleSQL,
                                Statement.RETURN_GENERATED_KEYS
                        );

                salePst.setInt(1, userId);
                salePst.setDouble(2, total);

                salePst.executeUpdate();

                ResultSet keys =
                        salePst.getGeneratedKeys();

                int saleId = 0;

                if (keys.next()) {
                    saleId = keys.getInt(1);
                }

                keys.close();
                salePst.close();

                if (saleId == 0) {
                    throw new SQLException(
                            "Could not create sale record."
                    );
                }

                // ------------------------------
                // Insert sale items
                // ------------------------------
                String itemSQL =
                        "INSERT INTO sale_items "
                        + "(sale_id, medicine_id, quantity_sold, "
                        + "price_at_sale) "
                        + "VALUES (?, ?, ?, ?)";

                PreparedStatement itemPst =
                        con.prepareStatement(itemSQL);

                // ------------------------------
                // Update medicine stock
                // ------------------------------
                String stockSQL =
                        "UPDATE medicines "
                        + "SET quantity_in_stock = quantity_in_stock - ? "
                        + "WHERE medicine_id = ? "
                        + "AND quantity_in_stock >= ?";

                PreparedStatement stockPst =
                        con.prepareStatement(stockSQL);

                for (int i = 0;
                        i < model.getRowCount();
                        i++) {

                    int medicineId =
                            Integer.parseInt(
                                    model.getValueAt(i, 0)
                                    .toString()
                            );

                    int quantity =
                            Integer.parseInt(
                                    model.getValueAt(i, 2)
                                    .toString()
                            );

                    double price =
                            Double.parseDouble(
                                    model.getValueAt(i, 3)
                                    .toString()
                            );

                    double subtotal =
                            Double.parseDouble(
                                    model.getValueAt(i, 4)
                                    .toString()
                            );

                    // Save sale item
                    itemPst.setInt(1, saleId);
                    itemPst.setInt(2, medicineId);
                    itemPst.setInt(3, quantity);
                    itemPst.setDouble(4, price);
                    itemPst.setDouble(5, subtotal);

                    itemPst.executeUpdate();

                    // Reduce stock
                    stockPst.setInt(1, quantity);
                    stockPst.setInt(2, medicineId);
                    stockPst.setInt(3, quantity);

                    int updated =
                            stockPst.executeUpdate();

                    if (updated == 0) {

                        throw new SQLException(
                                "Insufficient stock for "
                                + "medicine ID: "
                                + medicineId
                        );
                    }
                }

                itemPst.close();
                stockPst.close();

                con.commit();

                JOptionPane.showMessageDialog(
                        this,
                        "SALE COMPLETED!\n\n"
                        + "Sale ID: " + saleId
                        + "\nTotal: R "
                        + String.format("%.2f", total)
                        + "\nPaid: R "
                        + String.format("%.2f", amountPaid)
                        + "\nChange: R "
                        + String.format("%.2f", change),
                        "Sale Complete",
                        JOptionPane.INFORMATION_MESSAGE
                );

                clearSale();

            } catch (SQLException ex) {

                try {
                    con.rollback();
                } catch (SQLException rollbackEx) {
                    // Ignore rollback error
                }

                JOptionPane.showMessageDialog(
                        this,
                        "Sale failed. No changes were saved.\n\n"
                        + ex.getMessage(),
                        "Sale Error",
                        JOptionPane.ERROR_MESSAGE
                );

            } finally {

                try {
                    con.setAutoCommit(true);
                    con.close();
                } catch (SQLException ex) {
                    // Ignore close error
                }
            }

        } catch (NumberFormatException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Please enter a valid amount paid."
            );

        } catch (SQLException ex) {

            JOptionPane.showMessageDialog(
                    this,
                    "Database error:\n"
                    + ex.getMessage()
            );
        }
    }

    // ==============================
    // MAIN
    // ==============================
    public static void main(String args[]) {

        java.awt.EventQueue.invokeLater(
                new Runnable() {

            public void run() {

                // Temporary cashier user ID = 2
                new POS(2).setVisible(true);
            }
        });
    }
}
